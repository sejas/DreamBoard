<?php
//Si nos llaman directamente morimos
if (!isset($paginas)) die();
?>
<h2>Descarga</h2>
<ul>
<li><a href="propuesta.xml">Propuesta</a></li>
<li><a href="memoria.tar.gz">Memoria</a></li>
<li><a href="codigo.tar.gz">Codigo</a></li>
</ul>
