<?php
//Si nos llaman directamente morimos
if (!isset($paginas)) die();
?>
<h2>Enlaces</h2>
La demo del proyecto está disponible en <a href="http://antonio.sejas.es/proyectos/dreamboard/">http://antonio.sejas.es/proyectos/dreamboard/</a> y el repositorio con el código fuente en <a href="https://github.com/antoniosejas/DreamBoard">https://github.com/antoniosejas/DreamBoard</a>
<h3>Manuales e información</h3>
<ul>
<li><a href="http://box2d.org/">box2d</a></li>
<li><a href="http://www.w3schools.com/jquery/">jQuery</a></li>
<li><a href="http://www.w3schools.com/js/">JavaScript</a></li>
<li><a href="http://es.php.net">PHP</a></li>
<li><a href="http://www.mysql.com">MySql</a></li>
<li><a href="http://yuml.me/diagram/scruffy/class/draw"> Creación de UML online</a></li>

</ul>
