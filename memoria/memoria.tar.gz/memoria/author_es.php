<?php
//Si nos llaman directamente morimos
if (!isset($paginas)) die();
?>
<h2>Autor</h2>
<p> Nombre: Antonio Sejas Mustafá</p>
<p> Email: mynetsky+dreamboard@<script>document.write("gm"+""+"ail"+"."+"c"+"om")</script></p>
<p> Web: <a href="http://antonio.sejas.es">Antonio Sejas</a>

