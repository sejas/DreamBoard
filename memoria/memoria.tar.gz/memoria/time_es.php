<?php
//Si nos llaman directamente morimos
if (!isset($paginas)) die();
?>
<h2>Tiempo empleado</h2>

<p>Para el desarrollo de estea aplicación, habré invertido un total de 35 horas útiles. Tal vez podría haber acelerado el proceso usando algún framework de programación (como por ejemplo Yii, cake o Zend), sin embargo y debido a que buscaba una simplicidad de código y realizar un esqueleto de aplicación desde cero, opté por realizar desde cero todas las clases.</p>
<p>Posiblemente donde más tiempo he invertido ha sido en buscar una idea de proyecto con futuro y novedosa. Incluso actualmente esta no es del todo de mi agrado.</p>
