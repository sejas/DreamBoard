<?php
//Si nos llaman directamente morimos
if (!isset($paginas)) die();


?>
<h2>Futuras Mejoras</h2>
<p>Tanto el código como la lógica de negocio tienen bastantes mejoras suceptibles, pero una de las posibles mejoras que pueda aportar un valor añadido a este proyecto, sería la elaboración de dreamBoards Compartidos, donde la gente pueda añadir y editar proyectos e imágnes sobre el mismo tablero. </p>
<p>Otra posible mejora es que los usuarios puedan votar los dreamboards y en portada que aparezcan los últimos añadidos o los más votados. </p>
