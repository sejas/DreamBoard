<?php
//Si nos llaman directamente morimos
if (!isset($paginas)) die();
?>
<h2>Licencia</h2>

<p>
</p><h3>Las licencias utilizadas son:</h3>
<p>Tanto la documentación como el código fuente de la aplicación se distribuye bajo la licencia <a href="http://creativecommons.org/licenses/by-nc-sa/3.0/es/legalcode.es" target="_blank">Creative Commons Reconocimiento-No comercial-Compartir       bajo la misma licencia 3.0 España License</a></p>
<h3>Usted es libre de:</h3>
<ul>
  <li>Copiar, distribuir y comunicar públicamente la obra</li>
  <li>Hacer obras derivadas</li>
</ul>
<h3>Bajo las condiciones siguientes:</h3>
<ul>
  <li><strong>Reconocimiento</strong> — <span id="attribution-container">Debe  reconocer los créditos de la obra de la manera especificada por el  autor o el licenciador (pero no de una manera que sugiera que tiene su  apoyo o apoyan el uso que hace de su obra).</span></li>
  <li><strong>No comercial</strong> — No puede utilizar esta obra para fines comerciales. <span id="nc-more-container"> </span></li>
  <li><strong>Compartir bajo la misma licencia</strong> — Si  altera o transforma esta obra, o genera una obra derivada, sólo puede  distribuir la obra generada bajo una licencia idéntica a ésta.</li>
</ul>

<h3>Las licencias de los librerías que hemos usado:</h3>
 <ul>
 	<li><a href="http://jquery.org/license" target="_blank">jQuery license</a></li>
 </ul>
