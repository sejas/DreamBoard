   <!--start footer-->
   <footer>
   <div class="container">
   <section class="footer_left">
   <h3>Crea tu DreamBoard Gratis:
   <span>Logu&eacute;ate</span>
   <span>Reg&iacute;strate</span>
   </h3>
   </section> 
   
   <section class="footer_left">
   <h3>S&iacute;guenos:
   <span>Twitter</span>
   <span>facebook</span>
   </h3>
   </section> 

   
   <aside class="footer_left">
   <h3>Sobre el Autor:
   <span>P&aacutegina creada por <a href="http://antonio.sejas.es">Antonio Sejas</a></span>
   </h3>
   </aside> 
   <?php /*<img src="images/contact-us.png" width="240" height="230" alt="contact" class="picture_footer"/>*/ ?>

    
   <div id="FooterTwo"> 
   <a rel="license" href="http://creativecommons.org/licenses/by/3.0/es/"><img alt="Licencia Creative Commons" style="border-width:0" src="http://i.creativecommons.org/l/by/3.0/es/88x31.png" /></a><br />
   </div>
   </footer>
   <!--end footer-->
 <!-- Free template distributed by http://freehtml5templates.com -->  

   </body>
<?php Config::close(); ?>
</html>
